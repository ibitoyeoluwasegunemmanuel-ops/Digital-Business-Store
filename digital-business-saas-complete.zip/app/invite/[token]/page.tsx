'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';

export default function InvitePage() {
  const { token } = useParams<{ token: string }>();
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function accept() {
    setBusy(true); setMessage('');
    const r = await fetch('/api/staff/accept', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) });
    const j = await r.json();
    if (!r.ok) { setMessage(j.error || 'Could not accept invitation.'); setBusy(false); return; }
    router.push('/dashboard/business');
  }
  return <main className="auth"><section className="authbox"><p className="eyebrow">Team invitation</p><h1>Join a business</h1><p className="muted">Sign in with the invited email, then accept this invitation to access the business workspace.</p><button className="btn orange full" disabled={busy} onClick={accept}>{busy ? 'Accepting…' : 'Accept invitation'}</button>{message && <p className="notice">{message}</p>}<Link className="text-link" href="/auth/sign-in">Sign in</Link></section></main>;
}
