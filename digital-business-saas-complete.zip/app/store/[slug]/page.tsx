import Link from 'next/link';
import { createServerSupabaseClient } from '../../../lib/supabase-server';
import Storefront from './ui';

export default async function Store({params}:{params:Promise<{slug:string}>}) {
  const {slug}=await params;
  const supabase=await createServerSupabaseClient();
  const {data:business}=await supabase.from('businesses').select('*').eq('slug',slug).eq('status','PUBLISHED').maybeSingle();
  if(!business) return <main className="store-unavailable"><div className="card"><p className="eyebrow">Storefront</p><h1>This storefront is not available</h1><p className="muted">The business may still be setting up its store or the link may be incorrect.</p><Link className="btn orange" href="/">Go to platform</Link></div></main>;
  const [{data:products},{data:locations}]=await Promise.all([
    supabase.from('products').select('id,name,description,price,image_url,category,track_stock,stock_quantity').eq('business_id',business.id).eq('status','ACTIVE').order('created_at',{ascending:false}),
    supabase.from('locations').select('id,name,location_type').eq('business_id',business.id).eq('active',true).order('name')
  ]);
  return <Storefront business={business} products={products||[]} locations={locations||[]}/>;
}
