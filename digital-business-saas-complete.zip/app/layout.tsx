import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata={title:'Digital Business Store',description:'Create your digital storefront, accept orders and manage your business.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
