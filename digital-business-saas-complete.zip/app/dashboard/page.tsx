import { redirect } from 'next/navigation';
import { createServerSupabaseClient } from '../../lib/supabase-server';
import SetupBusiness from './setup';
export default async function Dashboard(){const supabase=await createServerSupabaseClient();const {data:{user}}=await supabase.auth.getUser();if(!user) redirect('/auth/sign-in');const {data:membership}=await supabase.from('memberships').select('business_id').eq('user_id',user.id).eq('status','ACTIVE').limit(1).maybeSingle();if(membership) redirect('/dashboard/business');return <SetupBusiness/>}
