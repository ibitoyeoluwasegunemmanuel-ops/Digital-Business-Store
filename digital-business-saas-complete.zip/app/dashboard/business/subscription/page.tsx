import Link from 'next/link';
import SubscriptionUI from './ui';
export default function Page(){return <SubscriptionUI/>}
