import { createServerSupabaseClient } from '../../../../lib/supabase-server';
import Link from 'next/link';

export default async function AnalyticsPage(){
 const supabase=await createServerSupabaseClient(); const {data:{user}}=await supabase.auth.getUser();
 if(!user) return null;
 const {data:m}=await supabase.from('memberships').select('business_id,role').eq('user_id',user.id).eq('status','ACTIVE').maybeSingle();
 if(!m) return null;
 const {data:rows}=await supabase.from('business_daily_sales').select('*').eq('business_id',m.business_id).order('sales_date',{ascending:false}).limit(30);
 const paid=(rows||[]).reduce((a,r)=>a+Number(r.paid_orders||0),0); const gross=(rows||[]).reduce((a,r)=>a+Number(r.gross_sales||0),0);
 return <main className="page"><div className="topbar"><div><p className="eyebrow">Analytics</p><h1>Business performance</h1><p className="muted">Paid orders and gross sales from your storefront.</p></div><Link className="btn" href="/dashboard/business">Back</Link></div><section className="cards"><div className="card"><span className="muted">Paid orders</span><strong>{paid}</strong></div><div className="card"><span className="muted">Gross sales</span><strong>₦{gross.toLocaleString()}</strong></div></section><section className="panel"><h2>Daily sales</h2><div className="tablewrap"><table><thead><tr><th>Date</th><th>Paid orders</th><th>Gross sales</th></tr></thead><tbody>{(rows||[]).map(r=><tr key={r.sales_date}><td>{r.sales_date}</td><td>{r.paid_orders}</td><td>₦{Number(r.gross_sales||0).toLocaleString()}</td></tr>)}</tbody></table></div></section></main>
}
