import Link from 'next/link';
import { createServerSupabaseClient } from '../../../lib/supabase-server';
import BusinessDashboard from './ui';

export default async function BusinessDashboardPage() {
  const supabase = await createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data: membership } = await supabase.from('memberships').select('business_id, role').eq('user_id', user.id).eq('status','ACTIVE').limit(1).maybeSingle();
  if (!membership) return <main className="auth"><section className="authbox"><h1>Set up your business</h1><p className="muted">You are signed in. Add your business details to start building your storefront.</p><Link className="btn orange full" href="/dashboard">Start setup</Link></section></main>;
  const [{data: business}, {data: products}, {data: orders}, {data: locations}] = await Promise.all([
    supabase.from('businesses').select('*').eq('id', membership.business_id).single(),
    supabase.from('products').select('*').eq('business_id', membership.business_id).neq('status','ARCHIVED').order('created_at',{ascending:false}),
    supabase.from('orders').select('*').eq('business_id', membership.business_id).order('created_at',{ascending:false}).limit(8),
    supabase.from('locations').select('*').eq('business_id', membership.business_id).eq('active',true).order('name'),
  ]);
  return <BusinessDashboard business={business} products={products||[]} orders={orders||[]} locations={locations||[]} role={membership.role}/>;
}
