import { createServerSupabaseClient } from '../../../../lib/supabase-server';
import Link from 'next/link';
import StaffClient from './ui';
export default async function StaffPage(){
 const s=await createServerSupabaseClient();const {data:{user}}=await s.auth.getUser();if(!user)return null;
 const {data:m}=await s.from('memberships').select('business_id,role').eq('user_id',user.id).eq('status','ACTIVE').maybeSingle();if(!m)return null;
 const {data:members}=await s.from('memberships').select('id,user_id,role,status,created_at').eq('business_id',m.business_id).order('created_at');
 const {data:invites}=await s.from('staff_invites').select('id,email,role,expires_at,accepted_at').eq('business_id',m.business_id).order('created_at',{ascending:false}).limit(20);
 return <main className="page"><div className="topbar"><div><p className="eyebrow">Team</p><h1>Staff & access</h1><p className="muted">Invite managers and staff with controlled access.</p></div><div className="top-actions"><Link className="btn ghost" href="/dashboard/business/notifications">Notifications</Link><Link className="btn" href="/dashboard/business">Back</Link></div></div><StaffClient role={m.role} members={members||[]} invites={invites||[]}/></main>
}
