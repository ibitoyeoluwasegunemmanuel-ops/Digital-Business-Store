import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createServerSupabaseClient } from '../../../../lib/supabase-server';
import OrdersUI from './ui';
export default async function OrdersPage(){
 const supabase=await createServerSupabaseClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user) redirect('/auth/sign-in');
 const {data:m}=await supabase.from('memberships').select('business_id,role').eq('user_id',user.id).eq('status','ACTIVE').limit(1).maybeSingle(); if(!m) redirect('/dashboard');
 const [{data:business},{data:orders}]=await Promise.all([
  supabase.from('businesses').select('id,name,slug,currency').eq('id',m.business_id).single(),
  supabase.from('orders').select('*,locations(name),order_items(*)').eq('business_id',m.business_id).order('created_at',{ascending:false}).limit(100)
 ]);
 if(!business) redirect('/dashboard');
 return <OrdersUI business={business} orders={orders||[]} role={m.role}/>;
}
