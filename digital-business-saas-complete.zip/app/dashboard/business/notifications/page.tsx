import Link from 'next/link';
import { createServerSupabaseClient } from '../../../../lib/supabase-server';

export default async function NotificationsPage() {
  const s = await createServerSupabaseClient();
  const { data: { user } } = await s.auth.getUser();
  if (!user) return null;
  const { data: m } = await s.from('memberships').select('business_id').eq('user_id', user.id).eq('status', 'ACTIVE').limit(1).maybeSingle();
  if (!m) return null;
  const { data: notifications } = await s.from('notifications').select('*').eq('business_id', m.business_id).order('created_at', { ascending: false }).limit(50);
  return <main className="page"><div className="topbar"><div><p className="eyebrow">Notifications</p><h1>Activity inbox</h1><p className="muted">Important events from your storefront and operations.</p></div><Link className="btn" href="/dashboard/business">Back</Link></div><section className="panel"><div className="notification-list">{(notifications || []).map(n => <article className={`notification ${n.read_at ? '' : 'unread'}`} key={n.id}><div><b>{n.title}</b><p>{n.message}</p></div><time>{new Date(n.created_at).toLocaleString()}</time></article>)}{!notifications?.length && <div className="empty"><b>No notifications yet</b><p>New paid orders and important business events will appear here.</p></div>}</div></section></main>;
}
