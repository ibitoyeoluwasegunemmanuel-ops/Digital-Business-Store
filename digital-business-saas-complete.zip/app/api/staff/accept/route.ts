import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { createServerSupabaseClient } from '../../../../lib/supabase-server';
import { createServiceSupabaseClient } from '../../../../lib/supabase-service';

export async function POST(request: Request) {
  const s = await createServerSupabaseClient();
  const { data: { user } } = await s.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Sign in before accepting an invitation.' }, { status: 401 });
  const body = await request.json();
  const token = String(body.token || '').trim();
  if (token.length < 40) return NextResponse.json({ error: 'Invalid invitation token.' }, { status: 400 });

  const hash = crypto.createHash('sha256').update(token).digest('hex');
  const service = createServiceSupabaseClient();
  const { data: invite, error } = await service.from('staff_invites').select('*').eq('token_hash', hash).is('accepted_at', null).gt('expires_at', new Date().toISOString()).maybeSingle();
  if (error || !invite) return NextResponse.json({ error: 'This invitation is invalid or has expired.' }, { status: 400 });
  if (String(user.email || '').toLowerCase() !== String(invite.email).toLowerCase()) {
    return NextResponse.json({ error: 'Sign in with the email address that received this invitation.' }, { status: 403 });
  }

  const { error: memberError } = await service.from('memberships').upsert({ business_id: invite.business_id, user_id: user.id, role: invite.role, status: 'ACTIVE' }, { onConflict: 'business_id,user_id' });
  if (memberError) return NextResponse.json({ error: memberError.message }, { status: 400 });
  await service.from('staff_invites').update({ accepted_at: new Date().toISOString() }).eq('id', invite.id);
  return NextResponse.json({ ok: true, business_id: invite.business_id, role: invite.role });
}
