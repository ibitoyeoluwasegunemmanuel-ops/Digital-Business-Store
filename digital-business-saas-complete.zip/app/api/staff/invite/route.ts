import {NextResponse} from 'next/server';
import crypto from 'crypto';
import {createServerSupabaseClient} from '../../../../lib/supabase-server';

export async function POST(request:Request){
  const s=await createServerSupabaseClient();
  const {data:{user}}=await s.auth.getUser();
  if(!user)return NextResponse.json({error:'Unauthorized'},{status:401});
  const {data:m}=await s.from('memberships').select('business_id,role').eq('user_id',user.id).eq('status','ACTIVE').limit(1).maybeSingle();
  if(!m || !['OWNER','MANAGER'].includes(m.role))return NextResponse.json({error:'Forbidden'},{status:403});
  const body=await request.json();const email=String(body.email||'').trim().toLowerCase();const role=String(body.role||'STAFF');
  if(!/^\S+@\S+\.\S+$/.test(email))return NextResponse.json({error:'Valid email is required.'},{status:400});
  if(!['MANAGER','STAFF'].includes(role))return NextResponse.json({error:'Invalid role.'},{status:400});
  if(m.role==='MANAGER' && role==='MANAGER')return NextResponse.json({error:'Only the owner can invite another manager.'},{status:403});
  const raw=crypto.randomBytes(32).toString('hex');const hash=crypto.createHash('sha256').update(raw).digest('hex');
  const expires=new Date(Date.now()+7*24*60*60*1000).toISOString();
  const {data:invite,error}=await s.from('staff_invites').insert({business_id:m.business_id,email,role,token_hash:hash,expires_at:expires,created_by:user.id}).select('id,email,role,expires_at').single();
  if(error)return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({invite,invite_token:raw});
}
