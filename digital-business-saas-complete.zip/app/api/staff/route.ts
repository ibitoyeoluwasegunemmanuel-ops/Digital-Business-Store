import {NextResponse} from 'next/server';
import {createServerSupabaseClient} from '../../../lib/supabase-server';
export async function GET(){
 const s=await createServerSupabaseClient();const {data:{user}}=await s.auth.getUser();if(!user)return NextResponse.json({error:'Unauthorized'},{status:401});
 const {data:m}=await s.from('memberships').select('business_id,role').eq('user_id',user.id).eq('status','ACTIVE').limit(1).maybeSingle();if(!m||!['OWNER','MANAGER'].includes(m.role))return NextResponse.json({error:'Forbidden'},{status:403});
 const {data,error}=await s.from('memberships').select('id,user_id,role,status,created_at').eq('business_id',m.business_id).order('created_at',{ascending:true});if(error)return NextResponse.json({error:error.message},{status:400});
 return NextResponse.json({memberships:data||[]});
}
