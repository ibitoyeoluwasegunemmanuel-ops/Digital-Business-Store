import { NextResponse } from 'next/server';
import { createServerSupabaseClient } from '../../../../../lib/supabase-server';
import { createServiceSupabaseClient } from '../../../../../lib/supabase-service';

async function requireAdmin() {
  const s = await createServerSupabaseClient();
  const { data: { user } } = await s.auth.getUser();
  if (!user || user.app_metadata?.platform_admin !== true) return null;
  return s;
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const s = await requireAdmin();
  if (!s) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  const { id } = await params;
  const body = await request.json();
  const status = String(body.status || '');
  if (!['DRAFT', 'PUBLISHED', 'SUSPENDED'].includes(status)) return NextResponse.json({ error: 'Invalid status.' }, { status: 400 });
  const service = createServiceSupabaseClient();
  const { data, error } = await service.from('businesses').update({ status, updated_at: new Date().toISOString() }).eq('id', id).select('id,name,slug,status,owner_id').single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  await service.from('audit_logs').insert({ actor_id: (await s.auth.getUser()).data.user?.id, business_id: id, action: 'admin.business_status_changed', entity_type: 'business', entity_id: id, metadata: { status } });
  return NextResponse.json({ business: data });
}
