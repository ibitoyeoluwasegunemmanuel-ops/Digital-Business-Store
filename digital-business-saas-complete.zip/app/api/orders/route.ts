import { NextResponse } from 'next/server';
import { createServerSupabaseClient } from '../../../lib/supabase-server';
export async function POST(request: Request) {
  const supabase=await createServerSupabaseClient(); const body=await request.json();
  const slug=String(body.slug||'').trim(), items=Array.isArray(body.items)?body.items:[], name=String(body.customer?.name||'').trim(), phone=String(body.customer?.phone||'').trim(), email=body.customer?.email?String(body.customer.email).trim():null, locationId=body.location_id?String(body.location_id):null;
  if(!slug||!name||!phone||!items.length)return NextResponse.json({error:'Business, customer details and at least one item are required.'},{status:400});
  const {data,error}=await supabase.rpc('create_public_order',{p_slug:slug,p_customer_name:name,p_customer_phone:phone,p_customer_email:email,p_location_id:locationId,p_items:items.map((i:any)=>({product_id:String(i.product_id),quantity:Number(i.quantity)}))});
  if(error)return NextResponse.json({error:error.message},{status:400}); return NextResponse.json({order:data});
}
