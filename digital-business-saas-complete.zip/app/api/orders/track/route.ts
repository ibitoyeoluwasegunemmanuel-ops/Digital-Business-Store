import { NextResponse } from 'next/server';
import { createServiceSupabaseClient } from '../../../../lib/supabase-service';

export async function GET(request: Request) {
  const token = new URL(request.url).searchParams.get('token')?.trim();
  if (!token || token.length < 20) return NextResponse.json({ error: 'Tracking token is required.' }, { status: 400 });
  const supabase = createServiceSupabaseClient();
  const { data, error } = await supabase
    .from('orders')
    .select('id,customer_name,total,status,payment_status,created_at,updated_at,businesses(name,currency),locations(name,location_type),order_items(name_snapshot,quantity,unit_price,line_total)')
    .eq('public_token', token)
    .single();
  if (error || !data) return NextResponse.json({ error: 'Order not found.' }, { status: 404 });
  return NextResponse.json({ order: data });
}
