import { NextResponse } from 'next/server';
import { createServerSupabaseClient } from '../../../../lib/supabase-server';

export async function PATCH(request: Request, { params }: { params: Promise<{id:string}> }) {
  const supabase = await createServerSupabaseClient();
  const { data:{user} } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({error:'Unauthorized'},{status:401});
  const { id } = await params;
  const body = await request.json();
  const status = String(body.status||'').trim();
  if (!status) return NextResponse.json({error:'Status is required'},{status:400});
  const { data, error } = await supabase.rpc('update_order_status',{p_order_id:id,p_status:status});
  if (error) return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({order:data});
}
