import { NextResponse } from 'next/server';
import { createServerSupabaseClient } from '../../../lib/supabase-server';

function slugify(value: string) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 70);
}

export async function POST(request: Request) {
  const supabase = await createServerSupabaseClient();
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const body = await request.json();
  const name = String(body.name || '').trim();
  const type = String(body.type || '').trim();
  if (!name || !type) return NextResponse.json({ error: 'Business name and type are required.' }, { status: 400 });

  let slug = slugify(name) || `business-${crypto.randomUUID().slice(0, 8)}`;
  const { data: existing } = await supabase.from('businesses').select('id').eq('slug', slug).maybeSingle();
  if (existing) slug = `${slug}-${crypto.randomUUID().slice(0, 6)}`;

  const { data: business, error } = await supabase.from('businesses').insert({
    owner_id: user.id, name, slug, type,
    phone: body.phone || null, city: body.city || null, description: body.description || null,
  }).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });

  const { error: memberError } = await supabase.from('memberships').insert({ business_id: business.id, user_id: user.id, role: 'OWNER', status: 'ACTIVE' });
  if (memberError) {
    await supabase.from('businesses').delete().eq('id', business.id);
    return NextResponse.json({ error: memberError.message }, { status: 400 });
  }
  const { data: starter } = await supabase.from('subscription_plans').select('id,trial_days').eq('code','STARTER').single();
  if (starter) {
    const trialEnd = new Date();
    trialEnd.setDate(trialEnd.getDate() + Number(starter.trial_days || 0));
    await supabase.from('business_subscriptions').insert({ business_id: business.id, plan_id: starter.id, status: starter.trial_days ? 'TRIAL' : 'ACTIVE', trial_ends_at: starter.trial_days ? trialEnd.toISOString() : null, current_period_end: trialEnd.toISOString() });
  }
  return NextResponse.json({ business });
}
