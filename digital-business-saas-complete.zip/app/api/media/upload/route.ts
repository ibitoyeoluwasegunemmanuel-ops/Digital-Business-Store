import { NextResponse } from 'next/server';
import { createServerSupabaseClient } from '../../../../lib/supabase-server';
import { createServiceSupabaseClient } from '../../../../lib/supabase-service';

const allowed = new Set(['image/jpeg','image/png','image/webp']);
const maxBytes = 5 * 1024 * 1024;

export async function POST(request: Request) {
  const s = await createServerSupabaseClient();
  const {data:{user}} = await s.auth.getUser();
  if (!user) return NextResponse.json({error:'Unauthorized'},{status:401});
  const {data:m} = await s.from('memberships').select('business_id,role').eq('user_id',user.id).eq('status','ACTIVE').limit(1).maybeSingle();
  if (!m || !['OWNER','MANAGER'].includes(m.role)) return NextResponse.json({error:'Forbidden'},{status:403});

  const form = await request.formData();
  const file = form.get('file');
  const kind = String(form.get('kind')||'OTHER');
  if (!(file instanceof File)) return NextResponse.json({error:'Image file is required.'},{status:400});
  if (!allowed.has(file.type)) return NextResponse.json({error:'Only JPG, PNG and WebP images are allowed.'},{status:400});
  if (file.size <= 0 || file.size > maxBytes) return NextResponse.json({error:'Image must be between 1 byte and 5 MB.'},{status:400});
  if (!['BUSINESS_LOGO','BUSINESS_COVER','PRODUCT_IMAGE','OTHER'].includes(kind)) return NextResponse.json({error:'Invalid media type.'},{status:400});

  const ext = file.type === 'image/jpeg' ? 'jpg' : file.type.split('/')[1];
  const path = `${m.business_id}/${kind.toLowerCase()}/${crypto.randomUUID()}.${ext}`;
  const service = createServiceSupabaseClient();
  const bytes = Buffer.from(await file.arrayBuffer());
  const {error:uploadError} = await service.storage.from('business-media').upload(path,bytes,{contentType:file.type,upsert:false});
  if (uploadError) return NextResponse.json({error:'Could not upload image.'},{status:500});
  const {data:publicUrl} = service.storage.from('business-media').getPublicUrl(path);
  const {data:asset,error:assetError} = await s.from('media_assets').insert({business_id:m.business_id,path,bucket:'business-media',mime_type:file.type,size_bytes:file.size,kind,created_by:user.id}).select().single();
  if (assetError) { await service.storage.from('business-media').remove([path]); return NextResponse.json({error:'Could not record image.'},{status:500}); }
  return NextResponse.json({asset,url:publicUrl.publicUrl});
}
