import {NextResponse} from 'next/server';
import {createServiceSupabaseClient} from '../../../../../lib/supabase-service';

export async function POST(request:Request){
  const body=await request.json();const token=String(body.public_token||'').trim();
  if(!token)return NextResponse.json({error:'Order tracking token is required.'},{status:400});
  const secret=process.env.PAYSTACK_SECRET_KEY;if(!secret)return NextResponse.json({error:'Payment provider is not configured yet.'},{status:503});
  const s=createServiceSupabaseClient();
  const {data:order,error}=await s.from('orders').select('id,business_id,customer_name,customer_email,total,payment_status,public_token,businesses(name,currency)').eq('public_token',token).single();
  if(error||!order)return NextResponse.json({error:'Order not found'},{status:404});
  if(order.payment_status==='PAID')return NextResponse.json({error:'Order is already paid'},{status:409});
  if(Number(order.total)<=0)return NextResponse.json({error:'Order total must be greater than zero.'},{status:400});
  const {data:existing}=await s.from('payments').select('authorization_url,provider_reference,status').eq('order_id',order.id).eq('provider','PAYSTACK').in('status',['PENDING','PROCESSING']).order('created_at',{ascending:false}).limit(1).maybeSingle();
  if(existing?.authorization_url)return NextResponse.json({authorization_url:existing.authorization_url,reference:existing.provider_reference,reused:true});
  const reference=`ORD_${order.id}_${Date.now()}`;
  const currency=(order.businesses as any)?.currency||'NGN';
  const {data:reserved,error:reserveError}=await s.from('payments').insert({business_id:order.business_id,order_id:order.id,provider:'PAYSTACK',provider_reference:reference,amount:order.total,currency,status:'PENDING',metadata:{reserved_at:new Date().toISOString()}}).select('id').single();
  if(reserveError){const {data:race}=await s.from('payments').select('authorization_url,provider_reference').eq('order_id',order.id).eq('provider','PAYSTACK').in('status',['PENDING','PROCESSING']).order('created_at',{ascending:false}).limit(1).maybeSingle();if(race)return NextResponse.json({authorization_url:race.authorization_url,reference:race.provider_reference,reused:true});return NextResponse.json({error:'Could not reserve payment attempt.'},{status:409});}
  const init=await fetch('https://api.paystack.co/transaction/initialize',{method:'POST',headers:{Authorization:`Bearer ${secret}`,'Content-Type':'application/json'},body:JSON.stringify({email:order.customer_email||`${order.id}@checkout.local`,amount:Math.round(Number(order.total)*100),currency,reference,metadata:{order_id:order.id,business_id:order.business_id,public_token:token}}),cache:'no-store'});
  const payload=await init.json();
  if(!init.ok||!payload.status){await s.from('payments').update({status:'FAILED',metadata:{error:payload?.message||'Paystack initialization failed'},updated_at:new Date().toISOString()}).eq('id',reserved.id);return NextResponse.json({error:payload.message||'Could not initialize payment'},{status:502});}
  await s.from('payments').update({status:'PROCESSING',authorization_url:payload.data.authorization_url,metadata:{access_code:payload.data.access_code},updated_at:new Date().toISOString()}).eq('id',reserved.id);
  await s.from('orders').update({payment_status:'PROCESSING',updated_at:new Date().toISOString()}).eq('id',order.id).eq('payment_status','PENDING');
  return NextResponse.json({authorization_url:payload.data.authorization_url,reference});
}
