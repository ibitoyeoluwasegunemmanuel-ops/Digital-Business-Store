import {NextResponse} from 'next/server';
import crypto from 'crypto';
import {createServiceSupabaseClient} from '../../../../../lib/supabase-service';

export async function POST(request:Request){
  const raw=await request.text();
  const secret=process.env.PAYSTACK_SECRET_KEY;
  if(!secret)return new NextResponse('Not configured',{status:503});
  const signature=request.headers.get('x-paystack-signature')||'';
  const expected=crypto.createHmac('sha512',secret).update(raw).digest('hex');
  if(!signature || signature.length!==expected.length || !crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected)))
    return new NextResponse('Invalid signature',{status:401});

  let event:any;
  try{event=JSON.parse(raw);}catch{return new NextResponse('Invalid payload',{status:400});}
  if(event.event!=='charge.success')return NextResponse.json({received:true});
  const d=event.data||{};
  const reference=String(d.reference||'');
  if(!reference)return new NextResponse('Missing reference',{status:400});

  const s=createServiceSupabaseClient();
  const {data:payment}=await s.from('payments').select('*').eq('provider_reference',reference).single();
  if(!payment)return NextResponse.json({received:true});
  if(payment.status==='PAID')return NextResponse.json({received:true});
  if(Math.round(Number(d.amount))!==Math.round(Number(payment.amount)*100))return new NextResponse('Amount mismatch',{status:400});
  if(String(d.currency||'').toUpperCase()!==String(payment.currency||'NGN').toUpperCase())return new NextResponse('Currency mismatch',{status:400});

  const {error}=await s.rpc('mark_order_paid',{p_order_id:payment.order_id,p_provider:'PAYSTACK',p_reference:reference,p_amount:payment.amount});
  if(error)return new NextResponse(error.message,{status:500});
  await s.from('payments').update({status:'PAID',paid_at:new Date().toISOString(),metadata:d,updated_at:new Date().toISOString()}).eq('id',payment.id);
  const {data:order} = await s.from('orders').select('customer_name,customer_email,business_id').eq('id',payment.order_id).single();
  if (order) {
    const {data:n} = await s.from('notifications').insert({business_id:order.business_id,type:'ORDER_PAID',title:'Payment received',message:`Order ${payment.order_id} has been paid successfully.`,data:{order_id:payment.order_id}}).select('id').single();
    if (n && order.customer_email) await s.from('notification_deliveries').insert({notification_id:n.id,channel:'EMAIL',destination:order.customer_email,status:'PENDING'});
  }
  return NextResponse.json({received:true});
}
