import { NextResponse } from "next/server";
import { createServiceSupabaseClient } from "../../../../lib/supabase-service";

export async function POST(request: Request) {
  const secret = process.env.NOTIFICATION_INTERNAL_SECRET;
  if (!secret || request.headers.get("x-notification-secret") !== secret) return NextResponse.json({error:"Forbidden"},{status:403});
  const body = await request.json();
  const deliveryId = String(body.delivery_id || "");
  if (!deliveryId) return NextResponse.json({error:"delivery_id is required"},{status:400});
  const s = createServiceSupabaseClient();
  const { data: delivery } = await s.from("notification_deliveries").select("*,notifications(*)").eq("id",deliveryId).single();
  if (!delivery) return NextResponse.json({error:"Delivery not found"},{status:404});
  if (delivery.status === "SENT") return NextResponse.json({ok:true,reused:true});
  if (delivery.channel !== "EMAIL") return NextResponse.json({error:"Only email delivery is configured in this release"},{status:409});
  const key = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!key || !from) return NextResponse.json({error:"Email provider is not configured"},{status:503});
  const n:any = delivery.notifications;
  const esc = (v:any) => String(v ?? "").replace(/[&<>"]/g, (c:string) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c] || c));
  const response = await fetch("https://api.resend.com/emails", {method:"POST",headers:{Authorization:`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify({from,to:[delivery.destination],subject:n.title,html:`<div style="font-family:Arial,sans-serif"><h2>${esc(n.title)}</h2><p>${esc(n.message)}</p></div>`}),cache:"no-store"});
  const payload = await response.json();
  if (!response.ok) { await s.from("notification_deliveries").update({status:"FAILED",attempts:Number(delivery.attempts||0)+1,last_error:payload?.message||"Email failed",updated_at:new Date().toISOString()}).eq("id",deliveryId); return NextResponse.json({error:"Email delivery failed"},{status:502}); }
  await s.from("notification_deliveries").update({status:"SENT",attempts:Number(delivery.attempts||0)+1,provider:"RESEND",provider_reference:payload.id||null,sent_at:new Date().toISOString(),updated_at:new Date().toISOString()}).eq("id",deliveryId);
  return NextResponse.json({ok:true});
}
