import {NextResponse} from 'next/server';
import {createServerSupabaseClient} from '../../../lib/supabase-server';

export async function GET(){
  const s=await createServerSupabaseClient();
  const {data:{user}}=await s.auth.getUser();
  if(!user)return NextResponse.json({error:'Unauthorized'},{status:401});
  const {data:m}=await s.from('memberships').select('business_id').eq('user_id',user.id).eq('status','ACTIVE').limit(1).maybeSingle();
  if(!m)return NextResponse.json({notifications:[]});
  const {data,error}=await s.from('notifications').select('*').eq('business_id',m.business_id).order('created_at',{ascending:false}).limit(50);
  if(error)return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({notifications:data||[]});
}

export async function PATCH(request:Request){
  const s=await createServerSupabaseClient();
  const {data:{user}}=await s.auth.getUser();
  if(!user)return NextResponse.json({error:'Unauthorized'},{status:401});
  const body=await request.json();const id=String(body.id||'');
  if(!id)return NextResponse.json({error:'Notification id is required.'},{status:400});
  const {data:m}=await s.from('memberships').select('business_id').eq('user_id',user.id).eq('status','ACTIVE').limit(1).maybeSingle();
  if(!m)return NextResponse.json({error:'Business not found.'},{status:404});
  const {data,error}=await s.from('notifications').update({read_at:new Date().toISOString()}).eq('id',id).eq('business_id',m.business_id).select().single();
  if(error)return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({notification:data});
}
