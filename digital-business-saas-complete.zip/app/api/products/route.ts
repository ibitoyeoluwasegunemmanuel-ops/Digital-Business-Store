import { NextResponse } from 'next/server';
import { createServerSupabaseClient } from '../../../lib/supabase-server';

async function getBusinessId(supabase: Awaited<ReturnType<typeof createServerSupabaseClient>>) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await supabase.from('memberships').select('business_id').eq('user_id', user.id).eq('status', 'ACTIVE').limit(1).maybeSingle();
  return data?.business_id ?? null;
}

export async function POST(request: Request) {
  const supabase = await createServerSupabaseClient();
  const businessId = await getBusinessId(supabase);
  if (!businessId) return NextResponse.json({ error: 'No active business found.' }, { status: 403 });
  const body = await request.json();
  const name = String(body.name || '').trim();
  const price = Number(body.price);
  if (!name) return NextResponse.json({ error: 'Product name is required.' }, { status: 400 });
  if (!Number.isFinite(price) || price < 0) return NextResponse.json({ error: 'Enter a valid non-negative price.' }, { status: 400 });
  const { data, error } = await supabase.from('products').insert({
    business_id: businessId, name, description: body.description || null,
    price, category: body.category || null, track_stock: Boolean(body.track_stock),
    stock_quantity: body.track_stock ? Number(body.stock_quantity || 0) : null,
    low_stock_threshold: body.track_stock ? Number(body.low_stock_threshold || 5) : null,
  }).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ product: data });
}
