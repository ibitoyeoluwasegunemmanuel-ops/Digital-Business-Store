import { NextResponse } from 'next/server';
import { createServerSupabaseClient } from '../../../../lib/supabase-server';

async function getContext() {
  const supabase = await createServerSupabaseClient();
  const { data:{user} } = await supabase.auth.getUser();
  if(!user) return {supabase,businessId:null as string|null,role:null as string|null};
  const {data}=await supabase.from('memberships').select('business_id,role').eq('user_id',user.id).eq('status','ACTIVE').limit(1).maybeSingle();
  return {supabase,businessId:data?.business_id??null,role:data?.role??null};
}
export async function PATCH(request:Request,{params}:{params:Promise<{id:string}>}){
 const {supabase,businessId,role}=await getContext(); if(!businessId)return NextResponse.json({error:'Unauthorized'},{status:401}); if(!['OWNER','MANAGER'].includes(role||''))return NextResponse.json({error:'Only owners and managers can edit products.'},{status:403});
 const {id}=await params;const body=await request.json();const allowed=['name','description','price','category','track_stock','stock_quantity','low_stock_threshold','image_url','status'];const update:any={};for(const key of allowed)if(key in body)update[key]=body[key];
 if('name' in update&&String(update.name).trim().length<1)return NextResponse.json({error:'Product name is required.'},{status:400});if('price' in update&&Number(update.price)<0)return NextResponse.json({error:'Price cannot be negative.'},{status:400});
 const {data,error}=await supabase.from('products').update(update).eq('id',id).eq('business_id',businessId).select().single();if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({product:data});
}
export async function DELETE(_request:Request,{params}:{params:Promise<{id:string}>}){const {supabase,businessId,role}=await getContext();if(!businessId)return NextResponse.json({error:'Unauthorized'},{status:401});if(!['OWNER','MANAGER'].includes(role||''))return NextResponse.json({error:'Forbidden'},{status:403});const {id}=await params;const {error}=await supabase.from('products').update({status:'ARCHIVED'}).eq('id',id).eq('business_id',businessId);if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({ok:true});}
