import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createServerSupabaseClient } from '../../../lib/supabase-server';
import { createServiceSupabaseClient } from '../../../lib/supabase-service';
import AdminBusinessesClient from './ui';
export default async function AdminBusinessesPage(){const s=await createServerSupabaseClient();const {data:{user}}=await s.auth.getUser();if(!user)redirect('/auth/sign-in');if(user.app_metadata?.platform_admin!==true)redirect('/admin');const service=createServiceSupabaseClient();const {data:businesses}=await service.from('businesses').select('id,name,slug,type,status,city,currency,created_at').order('created_at',{ascending:false}).limit(100);return <main className="page"><div className="topbar"><div><p className="eyebrow">Platform control</p><h1>Businesses</h1><p className="muted">Review and control tenant status.</p></div><Link className="btn" href="/admin">Back</Link></div><AdminBusinessesClient businesses={businesses||[]}/></main>}
