'use client';
import { useState } from 'react';
type Business={id:string;name:string;slug:string;type:string;status:string;city:string|null;currency:string;created_at:string};
export default function AdminBusinessesClient({businesses}:{businesses:Business[]}){
 const [rows,setRows]=useState(businesses);const [busy,setBusy]=useState('');const [message,setMessage]=useState('');
 async function change(id:string,status:string){setBusy(id);setMessage('');const r=await fetch(`/api/admin/businesses/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});const j=await r.json();if(!r.ok){setMessage(j.error||'Could not update business.');setBusy('');return}setRows(x=>x.map(b=>b.id===id?{...b,status}:b));setBusy('');}
 return <section className="panel">{message&&<p className="notice">{message}</p>}<div className="tablewrap"><table><thead><tr><th>Business</th><th>Type</th><th>Location</th><th>Status</th><th>Created</th><th></th></tr></thead><tbody>{rows.map(b=><tr key={b.id}><td><b>{b.name}</b><div className="muted">/{b.slug}</div></td><td>{b.type}</td><td>{b.city||'—'}</td><td><span className="pill">{b.status}</span></td><td>{new Date(b.created_at).toLocaleDateString()}</td><td>{b.status==='SUSPENDED'?<button className="btn ghost" disabled={busy===b.id} onClick={()=>change(b.id,'PUBLISHED')}>Restore</button>:<button className="btn ghost" disabled={busy===b.id} onClick={()=>change(b.id,'SUSPENDED')}>Suspend</button>}</td></tr>)}</tbody></table></div></section>
}
