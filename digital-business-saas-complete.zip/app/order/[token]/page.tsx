import Link from 'next/link';
import OrderTracker from './ui';
export default async function OrderPage({params}:{params:Promise<{token:string}>}) {
  const {token}=await params;
  return <OrderTracker token={token} />;
}
